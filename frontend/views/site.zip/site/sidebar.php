        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        Pilihan Library Infografis
                    </a>
                </li>
                <li>
                    <a href="index.php?r=site%2Finfografis2">ECharts Velocity</a>
                </li>
                <li>
                    <a href="index.php?r=site%2Fmultichart">ECharts Multichart</a>
                </li>
                <li>
                    <a href="index.php?r=site%2Fwatercontent">ECharts Water Content</a>
                </li>
                <li>
                    <a href="index.php?r=site%2Fmaps1">HighCharts Maps 1</a>
                </li>
                <li>
                    <a href="index.php?r=site%2Fmaps2">HighCharts Maps 2</a>
                </li>
                <li>
                    <a href="index.php?r=site%2Fjchart1">jChartFX 1</a>
                </li>
                <li>
                    <a href="index.php?r=site%2Fjchart2">jChartFX 2</a>
                </li>
            </ul>
        </div>
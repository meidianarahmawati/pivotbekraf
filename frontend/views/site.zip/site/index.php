<?php
    use yii\bootstrap\Collapse;
        $this->registerJsFile('@web/js/plotly-basic-latest.min.js');
        $this->registerJsFile('@web/js/jquery.min.js');
        $this->registerJsFile('@web/js/jquery-ui.min.js');
        $this->registerJsFile('@web/js/d3.min.js');
        $this->registerJsFile('@web/js/jquery.ui.touch-punch.min.js');
        $this->registerJsFile('@web/js/papaparse.min.js');
        $this->registerJsFile('@web/js/chosen.jquery.js');
        //$this->registerJsFile('@web/js/filesaver/src/FileSaver.js');
        $this->registerJsFile('@web/js/c3.min.js');
        $this->registerJsFile('@web/js/pivottable/dist/pivot.js');
        $this->registerJsFile('@web/js/pivottable/dist/d3_renderers.js');
        $this->registerJsFile('@web/js/pivottable/dist/c3_renderers.js');
        //$this->registerJsFile('@web/js/pivottable/dist/export_renderers.js');
        $this->registerJsFile('@web/js/pivottable/dist/plotly_renderers.js');
        //$this->registerJsFile('@web/js/pivottable/dist/renderers.js');
        //$this->registerJsFile('@web/js/pivottable/dist/derivers.js');
        //$this->registerJsFile('@web/js/parsecsv.js');

        $this->registerCssFile('@web/js/pivottable/dist/pivot.css');
?>

<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use frontend\models\MTabel;
use kartik\select2\Select2;

$this->title = 'BEKRAF Data';
?>
    <style type="text/css">
      .site-index{margin-left: 0px;margin-top: 0px;width: 99.9%;}
      /*.pvtUnused > li {display: none;}*/
      .pvtAggregator {display: none;}
    </style>
<div class="site-index">
    <div class="body-content">
        <p><div class="row">
        <?php 
            echo Html::beginForm(['index'], 'post');
            echo '<div class="col-sm-1" style="padding: 7px 2px 7px 25px;">Pilih Dataset :</div>';
            echo '<div class="col-sm-10">'.Select2::widget([
                'name' => 'id',
                'size' => Select2::MEDIUM,
                'value' => $id,
                'data' => $items,
                'options' => ['placeholder' => 'Pilih Dataset ...', 'onchange' => 'this.form.submit()', 'style' => 'width: 50%;display: inline-block'],
            ]).'</div>';
            echo Html::endForm();
            echo '<div class="col-sm-1">';
            echo Html::beginForm(['export'], 'post');
            echo Html::hiddenInput('table_id', $id);
            echo Html::submitButton('<span class="glyphicon glyphicon-save-file" aria-hidden="true">.xls</span>', ['class' => 'btn btn-link']);
            echo Html::endForm();
            echo '</div>';
        ?>            
        </div>
        <span id="doc"></span></p>
        <div id="output" style="margin: 10px;"></div>
        <a href="#" class="btn btn-secondary" style="color: white; background-color: black; border-radius: 0;" id="ekstrak"><span class="glyphicon glyphicon-scissors"></span></a>

    </div>
</div>

<?php
//include ("../models/get-data.php");
?>

<div id="isidata" style="display: none;"><?php echo $data; ?></div>

<script type="text/javascript">
// This example shows pivot() with a sum() aggregator
// with custom formatting (no digits after decimal)
$(function(){
    var tpl = $.pivotUtilities.aggregatorTemplates;
    var renderers = $.extend(
        $.pivotUtilities.renderers,
        $.pivotUtilities.plotly_renderers,
        );
    $("#output").pivotUI(
        $("#input"),
        <?php echo $konfig;?>
    );
 });

//ini buat ambil current pivot result
$("#ekstrak").click(function(event) {
    var dataid = $('#w0 option:selected').val();
    var table = $(".pvtRendererArea").html();
    $.ajax(
    {
        url: "../controllers/exportajax.php",
        type: "POST",

        data: { 
            dataid: dataid,
            tabel: table
        },
        success: function (result) {
                alert(result);

        }
    }); 
});
</script>